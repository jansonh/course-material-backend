const usersSchema = {
  name: String,
  email: String,
  password: String,
};

module.exports = usersSchema;
